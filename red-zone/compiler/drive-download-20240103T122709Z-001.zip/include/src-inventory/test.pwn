
#define INV_MAX_SLOTS				(32)

enum {
	SLOT_NONE,
	SLOT_GASCAN,
	SLOT_MAGIC_CRATE
}

Inventory:Init(type_max=>32);

public OnGameModeInit() {
	inventory.CreateItem(SLOT_NONE, 18685, "None");
	inventory.CreateItem(SLOT_GASCAN, 1650, "Gas Can");
	inventory.CreateItem(SLOT_MAGIC_CRATE, 19918, "Magic Crate");
}