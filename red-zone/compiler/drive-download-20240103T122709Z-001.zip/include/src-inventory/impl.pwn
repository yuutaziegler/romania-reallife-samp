

//////////////////////////////
////// Variabile /////////////
//////////////////////////////

#define INV_WITDH					(6)
#define INV_HEIGHT					(6)

#define MAX_INVENTAR_ITEMS  		(INV_WITDH * INV_HEIGHT)
#define MAX_ITEMS_INV				(MAX_INVENTAR_ITEMS * 2)

#define INVALID_INV_ITEM			(0)

#define MAX_INV_SLOTS				(500)
#define MAX_SHOP_ITEMS				(30)

#define MAX_ITEM_NAME 				(32)

#define Inventory: INV_
#define inventory. INV_

#define InvData: _INV_DATA
#define ShData: _SH_DATA

#define Shop:	SHOP_
#define shop.	SHOP_

new 
	ShData:Items[MAX_PLAYERS + 1][36] = {{-1, ...}, ...},
	InvData:Type[MAX_PLAYERS][MAX_ITEMS_INV],
	InvData:Value[MAX_PLAYERS][MAX_ITEMS_INV],
	InvData:Info[MAX_PLAYERS][MAX_ITEMS_INV][10],
	InvData:default_skin = 250,
	InvData:Skin[MAX_PLAYERS],
	InvData:Attach[MAX_PLAYERS][2][4],
	InvData:click_value[MAX_PLAYERS][PlayerText:MAX_PLAYER_TEXT_DRAWS];

new 
	Text: InventarTD[9], PlayerText: InventarPTD[MAX_PLAYERS][MAX_INVENTAR_ITEMS+11], PlayerText: invInfoPTD[MAX_PLAYERS][4] = {{PlayerText:INVALID_TEXT_DRAW, ...}, ...}, invInfo[MAX_PLAYERS][2] = {{-1,...},...}, bool: invPage[MAX_PLAYERS] = {false, ...}, PlayerShop[MAX_PLAYERS] = {-1,...},
	PlayerText: ShopPTD[MAX_PLAYERS][MAX_SHOP_ITEMS+1], PlayerText: ShopPricePTD[MAX_PLAYERS][MAX_SHOP_ITEMS] = {{PlayerText:INVALID_TEXT_DRAW, ...}, ...}, Text: ShopTD[7], PlayerText: InventarValPTD[MAX_PLAYERS][MAX_INVENTAR_ITEMS] = {{PlayerText:INVALID_TEXT_DRAW, ...}, ...}, InventarDeelay[MAX_PLAYERS],
	bool:inInventory[MAX_PLAYERS], string:inv_str[32], string:inv_query[1024], bool:inShop[MAX_PLAYERS]
;

#include <src-inventory\fronted>

enum ITEM_TYPE {
    ITEM_NAME[MAX_ITEM_NAME],
    ITEM_OBJECT,
    ITEM_PRICE,
    Float:ITEM_POS[4]
};
new ItemInfo[MAX_SHOP_ITEMS][ITEM_TYPE];


Shop:CreateItem(itemid, object_id, const _name[] = "Invalid", _value = 0, Float:pos_x=0.0,Float:pos_y=0.0,Float:pos_z=0.0,Float:zoom=1.0) {
	strmid(ItemInfo[itemid][ITEM_NAME], _name, 0, MAX_ITEM_NAME);
	ItemInfo[itemid][ITEM_OBJECT] = object_id;
	ItemInfo[itemid][ITEM_POS][0] = pos_x;
	ItemInfo[itemid][ITEM_POS][1] = pos_y;
	ItemInfo[itemid][ITEM_POS][2] = pos_z;
	ItemInfo[itemid][ITEM_POS][3] = zoom;
	ItemInfo[itemid][ITEM_PRICE] = _value;
	return true;
}

#define SHOP_Init(%0)		(ShData:Items[%0]=ShData:Items[MAX_PLAYERS])
#define SHOP_Add(%0,%1,%2)	ShData:Items[%0][%1]=%2
	
enum SLOT_INFO {
	SLOT_NAME[MAX_ITEM_NAME],
	SLOT_OBJECT,
	SLOT_VALUE,
	Float:SLOT_POS[4],
	SLOT_COLOR
}
new SlotInfo[MAX_INV_SLOTS][SLOT_INFO];

Inventory:CreateItem(itemid, object_id, const _name[] = "Invalid", _value = 0,_color=858993663, Float:pos_x=0.0,Float:pos_y=0.0,Float:pos_z=0.0,Float:zoom=1.0) {
	strmid(SlotInfo[itemid][SLOT_NAME], _name, 0, MAX_ITEM_NAME);
	SlotInfo[itemid][SLOT_OBJECT] = object_id;
	SlotInfo[itemid][SLOT_POS][0] = pos_x;
	SlotInfo[itemid][SLOT_POS][1] = pos_y;
	SlotInfo[itemid][SLOT_POS][2] = pos_z;
	SlotInfo[itemid][SLOT_POS][3] = zoom;
	SlotInfo[itemid][SLOT_COLOR] = _color;
	SlotInfo[itemid][SLOT_VALUE] = _value;
	return true;
}
Inventory:Hide(playerid, i=-1) {
	if(!inInventory[playerid]) return false;
	if(invInfo[playerid][0] != -1) inventory.HideOptions(playerid);
	while(++i<11) PlayerTextDrawDestroy(playerid, InventarPTD[playerid][i+MAX_INVENTAR_ITEMS]); i=-1;
	while(++i<9) TextDrawHideForPlayer(playerid, InventarTD[i]); i=-1;
	while(++i<MAX_INVENTAR_ITEMS) {
		PlayerTextDrawDestroy(playerid, InventarPTD[playerid][i]);
		if(InventarValPTD[playerid][i] == PlayerText:INVALID_TEXT_DRAW) continue;
		PlayerTextDrawDestroy(playerid, InventarValPTD[playerid][i]);
		InventarValPTD[playerid][i] = PlayerText:INVALID_TEXT_DRAW;
	}
	inInventory[playerid] = false;
	CancelSelectTextDraw(playerid);
	return true;
}

Inventory:Init(playerid, userid, skin, default_skin = 250) {
	InvData:default_skin = default_skin;
	InvData:Skin[playerid] = skin;

	mysql_format(SQL, inv_query, sizeof inv_query, "select * from `inventory` where `Userid` = '%i' limit 1;", userid);
	mysql_pquery(SQL, inv_query, #INV_Data_Status, #i, playerid);
	return true;
}

Inventory:Free(playerid, i=-1) {
	while(++i<MAX_ITEMS_INV)
		if(InvData:Type[playerid][i] == INVALID_INV_ITEM) 
			return i;

	return -1;
}

Inventory:Count(playerid, i = -1, count = 0) {
	for(;++i<MAX_ITEMS_INV;count+=_:(InvData:Type[playerid][i]!=INVALID_INV_ITEM)) {}
	return count;
}

Inventory:Add(playerid, itemid, amount = 1, const str_amount[] = "%d", slot=-2, i=-1, x=-1) {
	switch(slot) {
		case -1: {
			slot = inventory.Free(playerid);
			if(slot == -1) return false;
		}
		case -2: {
			while(++i<MAX_ITEMS_INV)
				if(InvData:Type[playerid][i] == itemid) { slot = i; break; }

			if(i==MAX_ITEMS_INV) slot = inventory.Free(playerid);
			if(slot == -1) return false;
		}
	}
	InvData:Value[playerid][slot] += amount, InvData:Type[playerid][slot] = itemid;
	format(InvData:Info[playerid][slot], 10, str_amount, InvData:Value[playerid][slot]);
	if(!inInventory[playerid]) return true;
	if(bool:(slot/MAX_INVENTAR_ITEMS)!=invPage[playerid]) return true;
	x = slot % MAX_INVENTAR_ITEMS;
	PlayerTextDrawSetPreviewModel(playerid, InventarPTD[playerid][x], SlotInfo[itemid][SLOT_OBJECT]);
	PlayerTextDrawSetPreviewRot(playerid, InventarPTD[playerid][x], SlotInfo[itemid][SLOT_POS][0], SlotInfo[itemid][SLOT_POS][1], SlotInfo[itemid][SLOT_POS][2], SlotInfo[itemid][SLOT_POS][3]);
	PlayerTextDrawBackgroundColor(playerid, InventarPTD[playerid][x], SlotInfo[itemid][SLOT_COLOR]);
	PlayerTextDrawShow(playerid, InventarPTD[playerid][x]);

	if(InvData:Value[playerid][slot]>1) {
		if(InventarValPTD[playerid][x]!=PlayerText:INVALID_TEXT_DRAW)
			PlayerTextDrawSetString(playerid, InventarValPTD[playerid][x], InvData:Info[playerid][slot]);			
		else {
			InventarValPTD[playerid][x] = CreatePlayerTextDraw(playerid, 363.599700 + ((slot%INV_WITDH) * 33.000000), 169.300018 + ((slot/INV_HEIGHT) * 31.9375), InvData:Info[playerid][slot]);
			PlayerTextDrawLetterSize(playerid, InventarValPTD[playerid][x], 0.155500, 1.013749);
			PlayerTextDrawAlignment(playerid, InventarValPTD[playerid][x], 3);
			PlayerTextDrawColor(playerid, InventarValPTD[playerid][x], -1);
			PlayerTextDrawSetShadow(playerid, InventarValPTD[playerid][x], 0);
			PlayerTextDrawSetOutline(playerid, InventarValPTD[playerid][x], 0);
			PlayerTextDrawBackgroundColor(playerid, InventarValPTD[playerid][x], 255);
			PlayerTextDrawFont(playerid, InventarValPTD[playerid][x], 2);
			PlayerTextDrawSetProportional(playerid, InventarValPTD[playerid][x], 1);
			PlayerTextDrawSetShadow(playerid, InventarValPTD[playerid][x], 0);

			PlayerTextDrawShow(playerid, InventarValPTD[playerid][x]);	
		}	
	}
	return true;
}

Inventory:RemoveSlot(playerid, slot, amount = 1, const str_amount[] = "%d", x=-1) {
	InvData:Value[playerid][slot] -= amount;
	if(InvData:Value[playerid][slot] < 1) 
		InvData:Value[playerid][slot] = 0,
		InvData:Type[playerid][slot] = 0;

	if(bool:(slot/MAX_INVENTAR_ITEMS)!=invPage[playerid]) 
		return true;

	x=slot%MAX_INVENTAR_ITEMS;
	switch(InvData:Value[playerid][slot]) {
		case 0: {
			PlayerTextDrawSetPreviewModel(playerid, InventarPTD[playerid][x], SlotInfo[0][SLOT_OBJECT]);
			PlayerTextDrawBackgroundColor(playerid, InventarPTD[playerid][x], 858993663);
			PlayerTextDrawShow(playerid, InventarPTD[playerid][x]);
			if(InventarValPTD[playerid][x]!=PlayerText:INVALID_TEXT_DRAW) PlayerTextDrawDestroy(playerid, InventarValPTD[playerid][x]), InventarValPTD[playerid][x] = PlayerText:INVALID_TEXT_DRAW;
		}
		case 1: if(InventarValPTD[playerid][x]!=PlayerText:INVALID_TEXT_DRAW) PlayerTextDrawDestroy(playerid, InventarValPTD[playerid][x]), InventarValPTD[playerid][x] = PlayerText:INVALID_TEXT_DRAW;
		default: {
			format(InvData:Info[playerid][slot], 10, str_amount, InvData:Value[playerid][slot]);
			PlayerTextDrawSetString(playerid, InventarValPTD[playerid][x], InvData:Info[playerid][slot]);
		}
	}
	return true;
}

#define INV_ClearSlot(%0,%1)	inventory.RemoveSlot(%0,%1,cellmax)

Inventory:AddAttach(playerid, attach_id, itemtype, value) {
	attach_id = attach_id % 4;
	InvData:Attach[playerid][0][attach_id] = itemtype;
	InvData:Attach[playerid][1][attach_id] = value;
	
	if(!inInventory[playerid]) return true;
	PlayerTextDrawSetPreviewModel(playerid, InventarPTD[playerid][39+attach_id], SlotInfo[itemtype][SLOT_OBJECT]);
	PlayerTextDrawSetPreviewRot(playerid, InventarPTD[playerid][39+attach_id], SlotInfo[itemtype][SLOT_POS][0], SlotInfo[itemtype][SLOT_POS][1], SlotInfo[itemtype][SLOT_POS][2], SlotInfo[itemtype][SLOT_POS][3]);
	PlayerTextDrawBackgroundColor(playerid, InventarPTD[playerid][39+attach_id], SlotInfo[itemtype][SLOT_COLOR]);
	PlayerTextDrawShow(playerid, InventarPTD[playerid][39+attach_id]);
	return true;
}

Inventory:RemoveAttach(playerid, attach_id) {
	attach_id = attach_id % 4;

	InvData:Attach[playerid][0][attach_id] = 0;
	InvData:Attach[playerid][1][attach_id] = 0;

	if(!inInventory[playerid]) return true;
	PlayerTextDrawSetPreviewModel(playerid, InventarPTD[playerid][39+attach_id], SlotInfo[0][SLOT_OBJECT]);
	PlayerTextDrawSetPreviewRot(playerid, InventarPTD[playerid][39+attach_id], SlotInfo[0][SLOT_POS][0], SlotInfo[0][SLOT_POS][1], SlotInfo[0][SLOT_POS][2], SlotInfo[0][SLOT_POS][3]);
	PlayerTextDrawBackgroundColor(playerid, InventarPTD[playerid][39+attach_id], SlotInfo[0][SLOT_COLOR]);
	PlayerTextDrawShow(playerid, InventarPTD[playerid][39+attach_id]);
	return true;
}

#define INV_GetAttach(%0,%1)		InvData:Attach[%0][0][%1]
#define INV_Value(%0,%1)			InvData:Value[%0][%1]
#define INV_GetSkin(%0)				InvData:Skin[%0]
#define INV_DefaultSkin()			InvData:default_skin
#define INV_AlreadySkin(%0)			(InvData:Skin[%0]!=InvData:default_skin)
#define INV_SlotInfo(%0,%1,%2)		format(InvData:Info[%0][%1],10,%2,InvData:Value[%0][%1])

Inventory:SetSkin(playerid, skinid) {
	InvData:Skin[playerid] = skinid;
	SetPlayerSkin(playerid, skinid);

	if(!inInventory[playerid]) return true;
	PlayerTextDrawSetPreviewModel(playerid, InventarPTD[playerid][38], skinid);
	PlayerTextDrawShow(playerid, InventarPTD[playerid][38]);

	PlayerTextDrawSetPreviewModel(playerid, InventarPTD[playerid][43], InvData:Skin[playerid] != InvData:default_skin?11745:18685);
	PlayerTextDrawShow(playerid, InventarPTD[playerid][43]);
	return true;
}

Inventory:Show(playerid) {
	if(inInventory[playerid]) return true;
	for(new i=0;i<9;i++) TextDrawShowForPlayer(playerid, InventarTD[i]);

	new z=-1, rx;
	while(++z<MAX_INVENTAR_ITEMS) {
		rx = InvData:Type[playerid][z]; 
		InventarPTD[playerid][z] = CreatePlayerTextDraw(playerid, 332.700286 + ((z % INV_WITDH) * 33.000000), 147.599975 + ((z / INV_HEIGHT) * 31.9375), "");
		PlayerTextDrawLetterSize(playerid, InventarPTD[playerid][z], 0.000000, 0.000000);
		PlayerTextDrawTextSize(playerid, InventarPTD[playerid][z], 32.000000, 31.000000);
		PlayerTextDrawAlignment(playerid, InventarPTD[playerid][z], 1);
		PlayerTextDrawColor(playerid, InventarPTD[playerid][z], -1);
		PlayerTextDrawSetShadow(playerid, InventarPTD[playerid][z], 0);
		PlayerTextDrawSetOutline(playerid, InventarPTD[playerid][z], 0);
		PlayerTextDrawFont(playerid, InventarPTD[playerid][z], 5);
		PlayerTextDrawSetProportional(playerid, InventarPTD[playerid][z], 0);
		PlayerTextDrawSetShadow(playerid, InventarPTD[playerid][z], 0);
		PlayerTextDrawSetPreviewModel(playerid, InventarPTD[playerid][z], SlotInfo[rx][SLOT_OBJECT]);
		PlayerTextDrawSetPreviewRot(playerid, InventarPTD[playerid][z], SlotInfo[rx][SLOT_POS][0], SlotInfo[rx][SLOT_POS][1], SlotInfo[rx][SLOT_POS][2], SlotInfo[rx][SLOT_POS][3]);
		PlayerTextDrawBackgroundColor(playerid, InventarPTD[playerid][z], SlotInfo[rx][SLOT_COLOR]);
		PlayerTextDrawSetPreviewVehCol(playerid, InventarPTD[playerid][z], 1, 1);
		PlayerTextDrawSetSelectable(playerid, InventarPTD[playerid][z], true);	
		PlayerTextDrawShow(playerid, InventarPTD[playerid][z]);		
		InvData:click_value[playerid][PlayerText:InventarPTD[playerid][z]] = z;
	} z=-1;
	while(++z<MAX_INVENTAR_ITEMS) {
		if(InvData:Value[playerid][z] < 2) continue;

		InventarValPTD[playerid][z] = CreatePlayerTextDraw(playerid, 363.599700 + ((z % INV_WITDH) * 33.000000), 169.300018 + ((z / INV_HEIGHT) * 31.9375), InvData:Info[playerid][z]);
		PlayerTextDrawLetterSize(playerid, InventarValPTD[playerid][z], 0.155500, 1.013749);
		PlayerTextDrawAlignment(playerid, InventarValPTD[playerid][z], 3);
		PlayerTextDrawColor(playerid, InventarValPTD[playerid][z], -1);
		PlayerTextDrawSetShadow(playerid, InventarValPTD[playerid][z], 0);
		PlayerTextDrawSetOutline(playerid, InventarValPTD[playerid][z], 0);
		PlayerTextDrawBackgroundColor(playerid, InventarValPTD[playerid][z], 255);
		PlayerTextDrawFont(playerid, InventarValPTD[playerid][z], 2);
		PlayerTextDrawSetProportional(playerid, InventarValPTD[playerid][z], 1);
		PlayerTextDrawSetShadow(playerid, InventarValPTD[playerid][z], 0);
		PlayerTextDrawShow(playerid, InventarValPTD[playerid][z]);
	}

	InventarPTD[playerid][36] = CreatePlayerTextDraw(playerid, 424.000000, 342.250000, "LD_BEAT:chit");
	PlayerTextDrawLetterSize(playerid, InventarPTD[playerid][36], 0.000000, 0.000000);
	PlayerTextDrawTextSize(playerid, InventarPTD[playerid][36], 10.000000, 9.000000);
	PlayerTextDrawAlignment(playerid, InventarPTD[playerid][36], 1);
	PlayerTextDrawColor(playerid, InventarPTD[playerid][36], 0xFF00FFFF);
	PlayerTextDrawSetShadow(playerid, InventarPTD[playerid][36], 0);
	PlayerTextDrawSetOutline(playerid, InventarPTD[playerid][36], 0);
	PlayerTextDrawBackgroundColor(playerid, InventarPTD[playerid][36], 255);
	PlayerTextDrawFont(playerid, InventarPTD[playerid][36], 4);
	PlayerTextDrawSetProportional(playerid, InventarPTD[playerid][36], 0);
	PlayerTextDrawSetShadow(playerid, InventarPTD[playerid][36], 0);
	PlayerTextDrawShow(playerid, InventarPTD[playerid][36]);			
	InvData:click_value[playerid][PlayerText:InventarPTD[playerid][36]] = 102;

	InventarPTD[playerid][37] = CreatePlayerTextDraw(playerid, 433.000000, 342.250000, "LD_BEAT:chit");
	PlayerTextDrawLetterSize(playerid, InventarPTD[playerid][37], 0.000000, 0.000000);
	PlayerTextDrawTextSize(playerid, InventarPTD[playerid][37], 10.000000, 9.000000);
	PlayerTextDrawAlignment(playerid, InventarPTD[playerid][37], 1);
	PlayerTextDrawColor(playerid, InventarPTD[playerid][37], 858993663);
	PlayerTextDrawSetShadow(playerid, InventarPTD[playerid][37], 0);
	PlayerTextDrawSetOutline(playerid, InventarPTD[playerid][37], 0);
	PlayerTextDrawBackgroundColor(playerid, InventarPTD[playerid][37], 255);
	PlayerTextDrawFont(playerid, InventarPTD[playerid][37], 4);
	PlayerTextDrawSetProportional(playerid, InventarPTD[playerid][37], 0);
	PlayerTextDrawSetShadow(playerid, InventarPTD[playerid][37], 0);
	PlayerTextDrawSetSelectable(playerid, InventarPTD[playerid][37], true);
	PlayerTextDrawShow(playerid, InventarPTD[playerid][37]);			
	InvData:click_value[playerid][PlayerText:InventarPTD[playerid][37]] = 103;

	InventarPTD[playerid][38] = CreatePlayerTextDraw(playerid, 213.700378, 154.562500, "");
	PlayerTextDrawLetterSize(playerid, InventarPTD[playerid][38], 0.000000, 0.000000);
	PlayerTextDrawTextSize(playerid, InventarPTD[playerid][38], 120.000000, 95.000000);
	PlayerTextDrawAlignment(playerid, InventarPTD[playerid][38], 1);
	PlayerTextDrawColor(playerid, InventarPTD[playerid][38], -1);
	PlayerTextDrawSetShadow(playerid, InventarPTD[playerid][38], 0);
	PlayerTextDrawSetOutline(playerid, InventarPTD[playerid][38], 0);
	PlayerTextDrawBackgroundColor(playerid, InventarPTD[playerid][38], 0);
	PlayerTextDrawFont(playerid, InventarPTD[playerid][38], 5);
	PlayerTextDrawSetProportional(playerid, InventarPTD[playerid][38], 0);
	PlayerTextDrawSetShadow(playerid, InventarPTD[playerid][38], 0);
	PlayerTextDrawSetPreviewModel(playerid, InventarPTD[playerid][38], InvData:Skin[playerid]);
	PlayerTextDrawSetPreviewRot(playerid, InventarPTD[playerid][38], 0.000000, 0.000000, 0.000000, 1.000000);
	PlayerTextDrawShow(playerid, InventarPTD[playerid][38]);

	new at = InvData:Attach[playerid][0][0];
	InventarPTD[playerid][39] = CreatePlayerTextDraw(playerid, 297.900634, 155.474975, "");
	PlayerTextDrawLetterSize(playerid, InventarPTD[playerid][39], 0.000000, 0.000000);
	PlayerTextDrawTextSize(playerid, InventarPTD[playerid][39], 23.000000, 23.000000);
	PlayerTextDrawAlignment(playerid, InventarPTD[playerid][39], 1);
	PlayerTextDrawColor(playerid, InventarPTD[playerid][39], -1);
	PlayerTextDrawSetShadow(playerid, InventarPTD[playerid][39], 0);
	PlayerTextDrawSetOutline(playerid, InventarPTD[playerid][39], 0);
	PlayerTextDrawBackgroundColor(playerid, InventarPTD[playerid][39], SlotInfo[at][SLOT_COLOR]);
	PlayerTextDrawFont(playerid, InventarPTD[playerid][39], 5);
	PlayerTextDrawSetProportional(playerid, InventarPTD[playerid][39], 0);
	PlayerTextDrawSetShadow(playerid, InventarPTD[playerid][39], 0);
	PlayerTextDrawSetSelectable(playerid, InventarPTD[playerid][39], true);
	PlayerTextDrawSetPreviewModel(playerid, InventarPTD[playerid][39], SlotInfo[at][SLOT_OBJECT]);
	PlayerTextDrawSetPreviewRot(playerid, InventarPTD[playerid][39], SlotInfo[at][SLOT_POS][0], SlotInfo[at][SLOT_POS][1], SlotInfo[at][SLOT_POS][2], SlotInfo[at][SLOT_POS][3]);
	PlayerTextDrawSetPreviewVehCol(playerid, InventarPTD[playerid][39], 1, 1);
	PlayerTextDrawShow(playerid, InventarPTD[playerid][39]);
	InvData:click_value[playerid][PlayerText:InventarPTD[playerid][39]] = 104;

	at = InvData:Attach[playerid][0][1];
	InventarPTD[playerid][40] = CreatePlayerTextDraw(playerid, 297.800445, 178.862487, "");
	PlayerTextDrawLetterSize(playerid, InventarPTD[playerid][40], 0.000000, 0.000000);
	PlayerTextDrawTextSize(playerid, InventarPTD[playerid][40], 23.000000, 23.000000);
	PlayerTextDrawAlignment(playerid, InventarPTD[playerid][40], 1);
	PlayerTextDrawColor(playerid, InventarPTD[playerid][40], -1);
	PlayerTextDrawSetShadow(playerid, InventarPTD[playerid][40], 0);
	PlayerTextDrawSetOutline(playerid, InventarPTD[playerid][40], 0);
	PlayerTextDrawBackgroundColor(playerid, InventarPTD[playerid][40], SlotInfo[at][SLOT_COLOR]);
	PlayerTextDrawFont(playerid, InventarPTD[playerid][40], 5);
	PlayerTextDrawSetProportional(playerid, InventarPTD[playerid][40], 0);
	PlayerTextDrawSetShadow(playerid, InventarPTD[playerid][40], 0);
	PlayerTextDrawSetSelectable(playerid, InventarPTD[playerid][40], true);
	PlayerTextDrawSetPreviewModel(playerid, InventarPTD[playerid][40], SlotInfo[at][SLOT_OBJECT]);
	PlayerTextDrawSetPreviewRot(playerid, InventarPTD[playerid][40], SlotInfo[at][SLOT_POS][0], SlotInfo[at][SLOT_POS][1], SlotInfo[at][SLOT_POS][2], SlotInfo[at][SLOT_POS][3]);
	PlayerTextDrawSetPreviewVehCol(playerid, InventarPTD[playerid][40], 1, 1);
	PlayerTextDrawShow(playerid, InventarPTD[playerid][40]);
	InvData:click_value[playerid][PlayerText:InventarPTD[playerid][40]] = 105;

	at = InvData:Attach[playerid][0][2];
	InventarPTD[playerid][41] = CreatePlayerTextDraw(playerid, 297.800476, 202.175262, "");
	PlayerTextDrawLetterSize(playerid, InventarPTD[playerid][41], 0.000000, 0.000000);
	PlayerTextDrawTextSize(playerid, InventarPTD[playerid][41], 23.000000, 23.000000);
	PlayerTextDrawAlignment(playerid, InventarPTD[playerid][41], 1);
	PlayerTextDrawColor(playerid, InventarPTD[playerid][41], -1);
	PlayerTextDrawSetShadow(playerid, InventarPTD[playerid][41], 0);
	PlayerTextDrawSetOutline(playerid, InventarPTD[playerid][41], 0);
	PlayerTextDrawBackgroundColor(playerid, InventarPTD[playerid][41], SlotInfo[at][SLOT_COLOR]);
	PlayerTextDrawFont(playerid, InventarPTD[playerid][41], 5);
	PlayerTextDrawSetProportional(playerid, InventarPTD[playerid][41], 0);
	PlayerTextDrawSetShadow(playerid, InventarPTD[playerid][41], 0);
	PlayerTextDrawSetSelectable(playerid, InventarPTD[playerid][41], true);
	PlayerTextDrawSetPreviewModel(playerid, InventarPTD[playerid][41], SlotInfo[at][SLOT_OBJECT]);
	PlayerTextDrawSetPreviewRot(playerid, InventarPTD[playerid][41], SlotInfo[at][SLOT_POS][0], SlotInfo[at][SLOT_POS][1], SlotInfo[at][SLOT_POS][2], SlotInfo[at][SLOT_POS][3]);
	PlayerTextDrawSetPreviewVehCol(playerid, InventarPTD[playerid][41], 1, 1);
	PlayerTextDrawShow(playerid, InventarPTD[playerid][41]);
	InvData:click_value[playerid][PlayerText:InventarPTD[playerid][41]] = 106;

	at = InvData:Attach[playerid][0][3];
	InventarPTD[playerid][42] = CreatePlayerTextDraw(playerid, 298.000518, 225.637512, "");
	PlayerTextDrawLetterSize(playerid, InventarPTD[playerid][42], 0.000000, 0.000000);
	PlayerTextDrawTextSize(playerid, InventarPTD[playerid][42], 23.000000, 23.000000);
	PlayerTextDrawAlignment(playerid, InventarPTD[playerid][42], 1);
	PlayerTextDrawColor(playerid, InventarPTD[playerid][42], -1);
	PlayerTextDrawSetShadow(playerid, InventarPTD[playerid][42], 0);
	PlayerTextDrawSetOutline(playerid, InventarPTD[playerid][42], 0);
	PlayerTextDrawBackgroundColor(playerid, InventarPTD[playerid][42], SlotInfo[at][SLOT_COLOR]);
	PlayerTextDrawFont(playerid, InventarPTD[playerid][42], 5);
	PlayerTextDrawSetProportional(playerid, InventarPTD[playerid][42], 0);
	PlayerTextDrawSetShadow(playerid, InventarPTD[playerid][42], 0);
	PlayerTextDrawSetSelectable(playerid, InventarPTD[playerid][42], true);
	PlayerTextDrawSetPreviewModel(playerid, InventarPTD[playerid][42], SlotInfo[at][SLOT_OBJECT]);
	PlayerTextDrawSetPreviewRot(playerid, InventarPTD[playerid][42], SlotInfo[at][SLOT_POS][0], SlotInfo[at][SLOT_POS][1], SlotInfo[at][SLOT_POS][2], SlotInfo[at][SLOT_POS][3]);
	PlayerTextDrawSetPreviewVehCol(playerid, InventarPTD[playerid][42], 1, 1);
	PlayerTextDrawShow(playerid, InventarPTD[playerid][42]);
	InvData:click_value[playerid][PlayerText:InventarPTD[playerid][42]] = 107;

	InventarPTD[playerid][43] = CreatePlayerTextDraw(playerid, 227.300598, 224.925262, "");
	PlayerTextDrawLetterSize(playerid, InventarPTD[playerid][43], 0.000000, 0.000000);
	PlayerTextDrawTextSize(playerid, InventarPTD[playerid][43], 23.000000, 23.000000);
	PlayerTextDrawAlignment(playerid, InventarPTD[playerid][43], 1);
	PlayerTextDrawColor(playerid, InventarPTD[playerid][43], -1);
	PlayerTextDrawSetShadow(playerid, InventarPTD[playerid][43], 0);
	PlayerTextDrawSetOutline(playerid, InventarPTD[playerid][43], 0);
	PlayerTextDrawBackgroundColor(playerid, InventarPTD[playerid][43], 858993663);
	PlayerTextDrawFont(playerid, InventarPTD[playerid][43], 5);
	PlayerTextDrawSetProportional(playerid, InventarPTD[playerid][43], 0);
	PlayerTextDrawSetShadow(playerid, InventarPTD[playerid][43], 0);
	PlayerTextDrawSetSelectable(playerid, InventarPTD[playerid][43], true);
	PlayerTextDrawSetPreviewModel(playerid, InventarPTD[playerid][43], InvData:Skin[playerid] != inventory.DefaultSkin()?11745:18685);
	PlayerTextDrawSetPreviewRot(playerid, InventarPTD[playerid][43], 0.000000, 0.000000, 0.800000, 0.699998);
	PlayerTextDrawSetPreviewVehCol(playerid, InventarPTD[playerid][43], 1, 1);
	PlayerTextDrawShow(playerid, InventarPTD[playerid][43]);
	InvData:click_value[playerid][PlayerText:InventarPTD[playerid][43]] = 108;

	InventarPTD[playerid][44] = CreatePlayerTextDraw(playerid, 264.400329, 251.687500, "0.0");
	PlayerTextDrawLetterSize(playerid, InventarPTD[playerid][44], 0.166997, 0.895623);
	PlayerTextDrawAlignment(playerid, InventarPTD[playerid][44], 3);
	PlayerTextDrawColor(playerid, InventarPTD[playerid][44], -1);
	PlayerTextDrawSetShadow(playerid, InventarPTD[playerid][44], 0);
	PlayerTextDrawSetOutline(playerid, InventarPTD[playerid][44], 0);
	PlayerTextDrawBackgroundColor(playerid, InventarPTD[playerid][44], 255);
	PlayerTextDrawFont(playerid, InventarPTD[playerid][44], 2);
	PlayerTextDrawSetProportional(playerid, InventarPTD[playerid][44], 1);
	PlayerTextDrawSetShadow(playerid, InventarPTD[playerid][44], 0);
	PlayerTextDrawShow(playerid, InventarPTD[playerid][44]);

	InventarPTD[playerid][45] = CreatePlayerTextDraw(playerid, 284.700317, 251.250000, "0.0");
	PlayerTextDrawLetterSize(playerid, InventarPTD[playerid][45], 0.166997, 0.895623);
	PlayerTextDrawAlignment(playerid, InventarPTD[playerid][45], 1);
	PlayerTextDrawColor(playerid, InventarPTD[playerid][45], -1);
	PlayerTextDrawSetShadow(playerid, InventarPTD[playerid][45], 0);
	PlayerTextDrawSetOutline(playerid, InventarPTD[playerid][45], 0);
	PlayerTextDrawBackgroundColor(playerid, InventarPTD[playerid][45], 255);
	PlayerTextDrawFont(playerid, InventarPTD[playerid][45], 2);
	PlayerTextDrawSetProportional(playerid, InventarPTD[playerid][45], 1);
	PlayerTextDrawSetShadow(playerid, InventarPTD[playerid][45], 0);
	PlayerTextDrawShow(playerid, InventarPTD[playerid][45]);

	GetPlayerName(playerid, inv_str, MAX_PLAYER_NAME);
	InventarPTD[playerid][46] = CreatePlayerTextDraw(playerid, 274.000000, 127.000000, inv_str);
	PlayerTextDrawLetterSize(playerid, InventarPTD[playerid][46], 0.238000, 1.236875);
	PlayerTextDrawAlignment(playerid, InventarPTD[playerid][46], 2);
	PlayerTextDrawColor(playerid, InventarPTD[playerid][46], -1);
	PlayerTextDrawSetShadow(playerid, InventarPTD[playerid][46], 0);
	PlayerTextDrawSetOutline(playerid, InventarPTD[playerid][46], 0);
	PlayerTextDrawBackgroundColor(playerid, InventarPTD[playerid][46], 255);
	PlayerTextDrawFont(playerid, InventarPTD[playerid][46], 2);
	PlayerTextDrawSetProportional(playerid, InventarPTD[playerid][46], 1);
	PlayerTextDrawSetShadow(playerid, InventarPTD[playerid][46], 0);
	PlayerTextDrawShow(playerid, InventarPTD[playerid][46]);

	invPage[playerid] = false; invInfo[playerid][0] = -1; invInfo[playerid][1] = -1;
	SelectTextDraw(playerid, 0xFF00FFFF);
	inInventory[playerid] = true;
	return true;
}

Inventory:HideOptions(playerid, i=-1) {
	while(++i<4) PlayerTextDrawDestroy(playerid, invInfoPTD[playerid][i]), invInfoPTD[playerid][i] = PlayerText:INVALID_TEXT_DRAW;
	if(invInfo[playerid][0] == -1) return true;
	PlayerTextDrawSetSelectable(playerid, InventarPTD[playerid][invInfo[playerid][0]], true);
	PlayerTextDrawShow(playerid, InventarPTD[playerid][invInfo[playerid][0]]);
	if(InventarValPTD[playerid][invInfo[playerid][0]] != PlayerText:INVALID_TEXT_DRAW) PlayerTextDrawShow(playerid, InventarValPTD[playerid][invInfo[playerid][0]]);
	invInfo[playerid][0] = -1;
	invInfo[playerid][1] = -1;
	return true;
}

Inventory:NextPage(playerid, bool:enable, z=-1, r=-1, rx=-1) {
	if(invPage[playerid]==enable) return true;
	invPage[playerid] = enable;
	PlayerTextDrawColor(playerid, InventarPTD[playerid][36], enable?858993663:0xFF00FFFF);
	PlayerTextDrawColor(playerid, InventarPTD[playerid][37], enable?0xFF00FFFF:858993663);
	PlayerTextDrawSetSelectable(playerid, InventarPTD[playerid][36], enable?true:false);
	PlayerTextDrawSetSelectable(playerid, InventarPTD[playerid][37], enable?false:true);
	PlayerTextDrawShow(playerid, InventarPTD[playerid][36]);
	PlayerTextDrawShow(playerid, InventarPTD[playerid][37]);
	if(invInfo[playerid][0] != -1) {
		for(new i=0;i<4;i++) PlayerTextDrawDestroy(playerid, invInfoPTD[playerid][i]), invInfoPTD[playerid][i] = PlayerText:INVALID_TEXT_DRAW;
		PlayerTextDrawSetSelectable(playerid, InventarPTD[playerid][invInfo[playerid][0]], true);
		PlayerTextDrawShow(playerid, InventarPTD[playerid][invInfo[playerid][0]]);
	}
	while(++z<MAX_INVENTAR_ITEMS) {
		r = (_:enable * MAX_INVENTAR_ITEMS) + z, rx=InvData:Type[playerid][r];
		PlayerTextDrawSetPreviewModel(playerid, InventarPTD[playerid][z], SlotInfo[rx][SLOT_OBJECT]);
		PlayerTextDrawSetPreviewRot(playerid, InventarPTD[playerid][z], SlotInfo[rx][SLOT_POS][0], SlotInfo[rx][SLOT_POS][1], SlotInfo[rx][SLOT_POS][2], SlotInfo[rx][SLOT_POS][3]);
		PlayerTextDrawBackgroundColor(playerid, InventarPTD[playerid][z], SlotInfo[rx][SLOT_COLOR]);
		PlayerTextDrawShow(playerid, InventarPTD[playerid][z]);
		if(InventarValPTD[playerid][z] != PlayerText:INVALID_TEXT_DRAW) PlayerTextDrawDestroy(playerid, InventarValPTD[playerid][z]), InventarValPTD[playerid][z] = PlayerText:INVALID_TEXT_DRAW;
		if(InvData:Value[playerid][r]<2) continue;

		InventarValPTD[playerid][z] = CreatePlayerTextDraw(playerid, 363.599700 + ((z%INV_WITDH) * 33.000000), 169.300018 + ((z/INV_HEIGHT) * 31.9375), InvData:Info[playerid][r]);
		PlayerTextDrawLetterSize(playerid, InventarValPTD[playerid][z], 0.155500, 1.013749);
		PlayerTextDrawAlignment(playerid, InventarValPTD[playerid][z], 3);
		PlayerTextDrawColor(playerid, InventarValPTD[playerid][z], -1);
		PlayerTextDrawSetShadow(playerid, InventarValPTD[playerid][z], 0);
		PlayerTextDrawSetOutline(playerid, InventarValPTD[playerid][z], 0);
		PlayerTextDrawBackgroundColor(playerid, InventarValPTD[playerid][z], 255);
		PlayerTextDrawFont(playerid, InventarValPTD[playerid][z], 2);
		PlayerTextDrawSetProportional(playerid, InventarValPTD[playerid][z], 1);
		PlayerTextDrawSetShadow(playerid, InventarValPTD[playerid][z], 0);
		PlayerTextDrawShow(playerid, InventarValPTD[playerid][z]);	
	}
	return true;
}


#define OnPlayerInvetarClick(%0)<%1> INV_%1(%0)
forward OnPlayerInvetarClick(playerid, slot, itemid)<using>;
forward OnPlayerInvetarClick(playerid, slot, itemid)<info>;

forward OnPlayerInvetarClick(playerid, attachid, attach_type)<attach>;
forward OnPlayerInvetarClick(playerid, bool:put)<skin>;

forward Inventory:Data_Cache(playerid, slot, type, value);
forward Shop:OnPlayerClick(playerid, slot, itemtype);

#include <YSI_Coding\y_hooks>

hook OnPlayerClickTextDraw(playerid, Text:clickedid) {
	if(clickedid == Text:INVALID_TEXT_DRAW) {
		if(inInventory[playerid]) return inventory.Hide(playerid);
		if(inShop[playerid]) return shop.Hide(playerid);
		return true;
	}
	return true;
}

DEFINE_HOOK_REPLACEMENT(OnPlayer, OP_);
hook OP_ClickPlayerTextDraw(playerid, PlayerText:playertextid) {
	if(inInventory[playerid]) {
		new z=InvData:click_value[playerid][PlayerText:playertextid], i = z+(_:invPage[playerid] * MAX_INVENTAR_ITEMS), l=invInfo[playerid][0], e = invInfo[playerid][1], y=(z%6),x=(z/6), _info[10];
		switch(z) {
			case 99: {
				if(e==-1) 
					return true;
			
				inventory.HideOptions(playerid);
				inventory.using(playerid, e, InvData:Type[playerid][e]);
				return true;
			}
			case 100: {
				if(e==-1) 
					return true;

				inventory.HideOptions(playerid);
				inventory.info(playerid, e, InvData:Type[playerid][e]);
			}
			case 101: return inventory.HideOptions(playerid);
			case 102: return inventory.NextPage(playerid, false);
			case 103: return inventory.NextPage(playerid, true);
			case 104..107: return inventory.attach(playerid, z-104, InvData:Attach[playerid][0][z-104]);
			case 108: return inventory.skin(playerid, InvData:Skin[playerid] != inventory.DefaultSkin());
		}
		if(e != -1) {
			if(invInfoPTD[playerid][0]!=PlayerText:INVALID_TEXT_DRAW) inventory.HideOptions(playerid);
			else invInfo[playerid][0] = invInfo[playerid][1] = -1;
			new rr = InvData:Value[playerid][i], ll = InvData:Type[playerid][i], tr = InvData:Type[playerid][e];
			InvData:Value[playerid][i] = InvData:Value[playerid][e];
			InvData:Type[playerid][i] = InvData:Type[playerid][e];
			InvData:Type[playerid][e] = ll;
			InvData:Value[playerid][e] = rr;

			_info = InvData:Info[playerid][i];
	 		InvData:Info[playerid][i] = InvData:Info[playerid][e];
	 		InvData:Info[playerid][e] = _info;

			PlayerTextDrawSetPreviewModel(playerid, InventarPTD[playerid][z], SlotInfo[tr][SLOT_OBJECT]);
			PlayerTextDrawSetPreviewRot(playerid, InventarPTD[playerid][z], SlotInfo[tr][SLOT_POS][0], SlotInfo[tr][SLOT_POS][1], SlotInfo[tr][SLOT_POS][2], SlotInfo[tr][SLOT_POS][3]);
			PlayerTextDrawBackgroundColor(playerid, InventarPTD[playerid][z], SlotInfo[tr][SLOT_COLOR]);
			PlayerTextDrawShow(playerid, InventarPTD[playerid][z]);

			if(InvData:Value[playerid][i]>1) {
				if(InventarValPTD[playerid][z]!=PlayerText:INVALID_TEXT_DRAW) PlayerTextDrawSetString(playerid, InventarValPTD[playerid][z], InvData:Info[playerid][i]);
				else {
					InventarValPTD[playerid][z] = CreatePlayerTextDraw(playerid, 363.599700 + (y * 33.000000), 169.300018 + (x * 31.9375), InvData:Info[playerid][i]);
					PlayerTextDrawLetterSize(playerid, InventarValPTD[playerid][z], 0.155500, 1.013749);
					PlayerTextDrawAlignment(playerid, InventarValPTD[playerid][z], 3);
					PlayerTextDrawColor(playerid, InventarValPTD[playerid][z], -1);
					PlayerTextDrawSetShadow(playerid, InventarValPTD[playerid][z], 0);
					PlayerTextDrawSetOutline(playerid, InventarValPTD[playerid][z], 0);
					PlayerTextDrawBackgroundColor(playerid, InventarValPTD[playerid][z], 255);
					PlayerTextDrawFont(playerid, InventarValPTD[playerid][z], 2);
					PlayerTextDrawSetProportional(playerid, InventarValPTD[playerid][z], 1);
					PlayerTextDrawSetShadow(playerid, InventarValPTD[playerid][z], 0);
					PlayerTextDrawShow(playerid, InventarValPTD[playerid][z]);			
				}
			} else if(InventarValPTD[playerid][z]!=PlayerText:INVALID_TEXT_DRAW) PlayerTextDrawDestroy(playerid, InventarValPTD[playerid][z]), InventarValPTD[playerid][z] = PlayerText:INVALID_TEXT_DRAW;
			
			if(bool:(e/MAX_INVENTAR_ITEMS)!=invPage[playerid]) return true;
			new nrx = InvData:Type[playerid][e];
			PlayerTextDrawSetPreviewModel(playerid, InventarPTD[playerid][l], SlotInfo[nrx][SLOT_OBJECT]);
			PlayerTextDrawSetPreviewRot(playerid, InventarPTD[playerid][l], SlotInfo[nrx][SLOT_POS][0], SlotInfo[nrx][SLOT_POS][1], SlotInfo[nrx][SLOT_POS][2], SlotInfo[nrx][SLOT_POS][3]);
			PlayerTextDrawBackgroundColor(playerid, InventarPTD[playerid][l], SlotInfo[nrx][SLOT_COLOR]);
			PlayerTextDrawShow(playerid, InventarPTD[playerid][l]);
			if(InvData:Value[playerid][e]>1) {
				if(InventarValPTD[playerid][l]!=PlayerText:INVALID_TEXT_DRAW) PlayerTextDrawSetString(playerid, InventarValPTD[playerid][l], InvData:Info[playerid][e]);
				else {
					InventarValPTD[playerid][l] = CreatePlayerTextDraw(playerid, 363.599700 + ((l%INV_WITDH) * 33.000000), 169.300018 + ((l/INV_HEIGHT) * 31.9375), InvData:Info[playerid][e]);
					PlayerTextDrawLetterSize(playerid, InventarValPTD[playerid][l], 0.155500, 1.013749);
					PlayerTextDrawAlignment(playerid, InventarValPTD[playerid][l], 3);
					PlayerTextDrawColor(playerid, InventarValPTD[playerid][l], -1);
					PlayerTextDrawSetShadow(playerid, InventarValPTD[playerid][l], 0);
					PlayerTextDrawSetOutline(playerid, InventarValPTD[playerid][l], 0);
					PlayerTextDrawBackgroundColor(playerid, InventarValPTD[playerid][l], 255);
					PlayerTextDrawFont(playerid, InventarValPTD[playerid][l], 2);
					PlayerTextDrawSetProportional(playerid, InventarValPTD[playerid][l], 1);
					PlayerTextDrawSetShadow(playerid, InventarValPTD[playerid][l], 0);
					PlayerTextDrawShow(playerid, InventarValPTD[playerid][l]);	
				}
			} else if(InventarValPTD[playerid][l]!=PlayerText:INVALID_TEXT_DRAW) PlayerTextDrawDestroy(playerid, InventarValPTD[playerid][l]), InventarValPTD[playerid][l] = PlayerText:INVALID_TEXT_DRAW;
			return true;
		}
		if(!InvData:Value[playerid][i]) return true;
		invInfo[playerid][0] = z; invInfo[playerid][1] = i;

		PlayerTextDrawSetSelectable(playerid, playertextid, false);
		PlayerTextDrawShow(playerid, playertextid);
		if(InventarValPTD[playerid][z] != PlayerText:INVALID_TEXT_DRAW) 
			PlayerTextDrawHide(playerid, InventarValPTD[playerid][z]);

		invInfoPTD[playerid][0] = CreatePlayerTextDraw(playerid, 349.900085 + (y * 33.000000), 166.375000 + (x * 31.9375), "box");
		PlayerTextDrawLetterSize(playerid, invInfoPTD[playerid][0], 0.000000, 4.210990);
		PlayerTextDrawTextSize(playerid, invInfoPTD[playerid][0], 0.000000, 43.000000);
		PlayerTextDrawAlignment(playerid, invInfoPTD[playerid][0], 2);
		PlayerTextDrawColor(playerid, invInfoPTD[playerid][0], -1);
		PlayerTextDrawUseBox(playerid, invInfoPTD[playerid][0], 1);
		PlayerTextDrawBoxColor(playerid, invInfoPTD[playerid][0], 0x11111160);
		PlayerTextDrawSetShadow(playerid, invInfoPTD[playerid][0], 0);
		PlayerTextDrawSetOutline(playerid, invInfoPTD[playerid][0], 0);
		PlayerTextDrawBackgroundColor(playerid, invInfoPTD[playerid][0], 255);
		PlayerTextDrawFont(playerid, invInfoPTD[playerid][0], 1);
		PlayerTextDrawSetProportional(playerid, invInfoPTD[playerid][0], 1);
		PlayerTextDrawSetShadow(playerid, invInfoPTD[playerid][0], 0);

		invInfoPTD[playerid][1] = CreatePlayerTextDraw(playerid, 350.000000 + (y * 33.000000), 167.599700 + (x * 31.9375), "USE");
		PlayerTextDrawLetterSize(playerid, invInfoPTD[playerid][1], 0.282000, 1.004999);
		PlayerTextDrawTextSize(playerid, invInfoPTD[playerid][1], 15.000000, 41.000000);
		PlayerTextDrawAlignment(playerid, invInfoPTD[playerid][1], 2);
		PlayerTextDrawColor(playerid, invInfoPTD[playerid][1], -1);
		PlayerTextDrawUseBox(playerid, invInfoPTD[playerid][1], 1);
		PlayerTextDrawBoxColor(playerid, invInfoPTD[playerid][1], 858993663);
		PlayerTextDrawSetShadow(playerid, invInfoPTD[playerid][1], 0);
		PlayerTextDrawSetOutline(playerid, invInfoPTD[playerid][1], 0);
		PlayerTextDrawBackgroundColor(playerid, invInfoPTD[playerid][1], 255);
		PlayerTextDrawFont(playerid, invInfoPTD[playerid][1], 1);
		PlayerTextDrawSetProportional(playerid, invInfoPTD[playerid][1], 1);
		PlayerTextDrawSetShadow(playerid, invInfoPTD[playerid][1], 0);
		PlayerTextDrawSetSelectable(playerid, invInfoPTD[playerid][1], true);
		InvData:click_value[playerid][PlayerText:invInfoPTD[playerid][1]] = 99;

		invInfoPTD[playerid][2] = CreatePlayerTextDraw(playerid, 349.799865 + (y * 33.000000), 180.762176 + (x * 31.9375), "INFO");
		PlayerTextDrawLetterSize(playerid, invInfoPTD[playerid][2], 0.282000, 1.004999);
		PlayerTextDrawTextSize(playerid, invInfoPTD[playerid][2], 15.000000, 41.000000);
		PlayerTextDrawAlignment(playerid, invInfoPTD[playerid][2], 2);
		PlayerTextDrawColor(playerid, invInfoPTD[playerid][2], -1);
		PlayerTextDrawUseBox(playerid, invInfoPTD[playerid][2], 1);
		PlayerTextDrawBoxColor(playerid, invInfoPTD[playerid][2], 858993663);
		PlayerTextDrawSetShadow(playerid, invInfoPTD[playerid][2], 0);
		PlayerTextDrawSetOutline(playerid, invInfoPTD[playerid][2], 0);
		PlayerTextDrawBackgroundColor(playerid, invInfoPTD[playerid][2], 255);
		PlayerTextDrawFont(playerid, invInfoPTD[playerid][2], 1);
		PlayerTextDrawSetProportional(playerid, invInfoPTD[playerid][2], 1);
		PlayerTextDrawSetShadow(playerid, invInfoPTD[playerid][2], 0);
		PlayerTextDrawSetSelectable(playerid, invInfoPTD[playerid][2], true);
		InvData:click_value[playerid][PlayerText:invInfoPTD[playerid][2]] = 100;

		invInfoPTD[playerid][3] = CreatePlayerTextDraw(playerid, 349.799865 + (y * 33.000000), 193.949707 + (x * 31.9375), "CLOSE");
		PlayerTextDrawLetterSize(playerid, invInfoPTD[playerid][3], 0.282000, 1.004999);
		PlayerTextDrawTextSize(playerid, invInfoPTD[playerid][3], 15.000000, 41.000000);
		PlayerTextDrawAlignment(playerid, invInfoPTD[playerid][3], 2);
		PlayerTextDrawColor(playerid, invInfoPTD[playerid][3], -1);
		PlayerTextDrawUseBox(playerid, invInfoPTD[playerid][3], 1);
		PlayerTextDrawBoxColor(playerid, invInfoPTD[playerid][3], -1539424513);
		PlayerTextDrawSetShadow(playerid, invInfoPTD[playerid][3], 0);
		PlayerTextDrawSetOutline(playerid, invInfoPTD[playerid][3], 0);
		PlayerTextDrawBackgroundColor(playerid, invInfoPTD[playerid][3], 255);
		PlayerTextDrawFont(playerid, invInfoPTD[playerid][3], 1);
		PlayerTextDrawSetProportional(playerid, invInfoPTD[playerid][3], 1);
		PlayerTextDrawSetShadow(playerid, invInfoPTD[playerid][3], 0);
		PlayerTextDrawSetSelectable(playerid, invInfoPTD[playerid][3], true);
		InvData:click_value[playerid][PlayerText:invInfoPTD[playerid][3]] = 101;

		for(new rx=0;rx<4;rx++) PlayerTextDrawShow(playerid, invInfoPTD[playerid][rx]);
		return true;
	}
	if(inShop[playerid]) {
		new click = InvData:click_value[playerid][PlayerText:playertextid];
		switch click 
		do {
			case 0 .. 29: shop.OnPlayerClick(playerid, click, ShData:Items[playerid][click]);
			case 400: return shop.InvPage(playerid, false);
			case 401: return shop.InvPage(playerid, true);
		}
	}
	return true;
}

forward Inventory:Data_Status(playerid);
public Inventory:Data_Status(playerid) {
	if(!cache_num_rows()) return true;
	cache_get_value_name(0, "Type", inv_query);
	sscanf(inv_query, "a<i>[72]", InvData:Type[playerid]);

	cache_get_value_name(0, "Value", inv_query);
	sscanf(inv_query, "a<i>[72]", InvData:Value[playerid]);

	cache_get_value_name(0, "AttachType", inv_query);
	sscanf(inv_query, "a<i>[4]", InvData:Attach[playerid][0]);

	cache_get_value_name(0, "AttachValue", inv_query);
	sscanf(inv_query, "a<i>[4]", InvData:Attach[playerid][1]);
	for(new i=0;++i<72;) inventory.Data_Cache(playerid, i, InvData:Type[playerid][i], InvData:Value[playerid][i]);
	return true;
}

#define INV_SetupSQL(%0) mysql_format(SQL, inv_query, sizeof inv_query, "insert into `inventory` (`Userid`) values ('%i')",%0)&&mysql_tquery(SQL,inv_query)

Inventory:UpdateData(playerid, userid) {
	mysql_format(SQL, inv_query, sizeof inv_query, "update `inventory` SET `Type` = '%i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i' where `Userid` = '%i'",
		InvData:Type[playerid][0], InvData:Type[playerid][1], InvData:Type[playerid][2], InvData:Type[playerid][3], InvData:Type[playerid][4], InvData:Type[playerid][5], InvData:Type[playerid][6], InvData:Type[playerid][7], InvData:Type[playerid][8], InvData:Type[playerid][9],
		InvData:Type[playerid][10], InvData:Type[playerid][11], InvData:Type[playerid][12], InvData:Type[playerid][13], InvData:Type[playerid][14], InvData:Type[playerid][15], InvData:Type[playerid][16], InvData:Type[playerid][17], InvData:Type[playerid][18], InvData:Type[playerid][19],
		InvData:Type[playerid][20], InvData:Type[playerid][21], InvData:Type[playerid][22], InvData:Type[playerid][23], InvData:Type[playerid][24], InvData:Type[playerid][25], InvData:Type[playerid][26], InvData:Type[playerid][27], InvData:Type[playerid][28], InvData:Type[playerid][29],
		InvData:Type[playerid][30], InvData:Type[playerid][31], InvData:Type[playerid][32], InvData:Type[playerid][33], InvData:Type[playerid][34], InvData:Type[playerid][35], InvData:Type[playerid][36], InvData:Type[playerid][37], InvData:Type[playerid][38], InvData:Type[playerid][39],
		InvData:Type[playerid][40], InvData:Type[playerid][41], InvData:Type[playerid][42], InvData:Type[playerid][43], InvData:Type[playerid][44], InvData:Type[playerid][45], InvData:Type[playerid][46], InvData:Type[playerid][47], InvData:Type[playerid][48], InvData:Type[playerid][49],
		InvData:Type[playerid][50], InvData:Type[playerid][51], InvData:Type[playerid][52], InvData:Type[playerid][53], InvData:Type[playerid][54], InvData:Type[playerid][55], InvData:Type[playerid][56], InvData:Type[playerid][57], InvData:Type[playerid][58], InvData:Type[playerid][59],
		InvData:Type[playerid][60], InvData:Type[playerid][61], InvData:Type[playerid][62], InvData:Type[playerid][63], InvData:Type[playerid][64], InvData:Type[playerid][65], InvData:Type[playerid][66], InvData:Type[playerid][67], InvData:Type[playerid][68], InvData:Type[playerid][69],
		InvData:Type[playerid][70], InvData:Type[playerid][71], userid);
	mysql_tquery(SQL, inv_query);

	mysql_format(SQL, inv_query, sizeof inv_query, "update `inventory` SET `Value` = '%i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i %i' where `Userid` = '%i'",
		InvData:Value[playerid][0], InvData:Value[playerid][1], InvData:Value[playerid][2], InvData:Value[playerid][3], InvData:Value[playerid][4], InvData:Value[playerid][5], InvData:Value[playerid][6], InvData:Value[playerid][7], InvData:Value[playerid][8], InvData:Value[playerid][9],
		InvData:Value[playerid][10], InvData:Value[playerid][11], InvData:Value[playerid][12], InvData:Value[playerid][13], InvData:Value[playerid][14], InvData:Value[playerid][15], InvData:Value[playerid][16], InvData:Value[playerid][17], InvData:Value[playerid][18], InvData:Value[playerid][19],
		InvData:Value[playerid][20], InvData:Value[playerid][21], InvData:Value[playerid][22], InvData:Value[playerid][23], InvData:Value[playerid][24], InvData:Value[playerid][25], InvData:Value[playerid][26], InvData:Value[playerid][27], InvData:Value[playerid][28], InvData:Value[playerid][29],
		InvData:Value[playerid][30], InvData:Value[playerid][31], InvData:Value[playerid][32], InvData:Value[playerid][33], InvData:Value[playerid][34], InvData:Value[playerid][35], InvData:Value[playerid][36], InvData:Value[playerid][37], InvData:Value[playerid][38], InvData:Value[playerid][39],
		InvData:Value[playerid][40], InvData:Value[playerid][41], InvData:Value[playerid][42], InvData:Value[playerid][43], InvData:Value[playerid][44], InvData:Value[playerid][45], InvData:Value[playerid][46], InvData:Value[playerid][47], InvData:Value[playerid][48], InvData:Value[playerid][49],
		InvData:Value[playerid][50], InvData:Value[playerid][51], InvData:Value[playerid][52], InvData:Value[playerid][53], InvData:Value[playerid][54], InvData:Value[playerid][55], InvData:Value[playerid][56], InvData:Value[playerid][57], InvData:Value[playerid][58], InvData:Value[playerid][59],
		InvData:Value[playerid][60], InvData:Value[playerid][61], InvData:Value[playerid][62], InvData:Value[playerid][63], InvData:Value[playerid][64], InvData:Value[playerid][65], InvData:Value[playerid][66], InvData:Value[playerid][67], InvData:Value[playerid][68], InvData:Value[playerid][69],
		InvData:Value[playerid][70], InvData:Value[playerid][71], userid);
	mysql_tquery(SQL, inv_query);

	mysql_format(SQL, inv_query, sizeof inv_query, "update `inventory` SET `AttachType` = '%i %i %i %i' where `Userid` = '%i'", InvData:Attach[playerid][0][0], InvData:Attach[playerid][0][1], InvData:Attach[playerid][0][2], InvData:Attach[playerid][0][3], userid);
	mysql_tquery(SQL, inv_query);
	mysql_format(SQL, inv_query, sizeof inv_query, "update `inventory` SET `AttachValue` = '%i %i %i %i' where `Userid` = '%i'", InvData:Attach[playerid][1][0], InvData:Attach[playerid][1][1], InvData:Attach[playerid][1][2], InvData:Attach[playerid][1][3], userid);
	mysql_tquery(SQL, inv_query);
	return true;
}

//////////////////////////////////////////////////
////////// Shoping ///////////////////////////////
//////////////////////////////////////////////////

Shop:Show(playerid, z=-1) {
	if(inShop[playerid]) return true;
	inShop[playerid] = true;
	SelectTextDraw(playerid, 0xFF00FFFF);

	while(++z<5) TextDrawShowForPlayer(playerid, InventarTD[z]); z=-1;
	while(++z<7) TextDrawShowForPlayer(playerid, ShopTD[z]); z=-1;

	new x=-1,y=-1;
	while(++y<6) {
		while(++x<5) {
			ShopPTD[playerid][++z] = CreatePlayerTextDraw(playerid, 158.799926 + (x * 33.000000), 147.787780 + (y * 31.9375), "");
			PlayerTextDrawLetterSize(playerid, ShopPTD[playerid][z], 0.000000, 0.000000);
			PlayerTextDrawTextSize(playerid, ShopPTD[playerid][z], 32.000000, 31.000000);
			PlayerTextDrawAlignment(playerid, ShopPTD[playerid][z], 1);
			PlayerTextDrawColor(playerid, ShopPTD[playerid][z], -1);
			PlayerTextDrawSetShadow(playerid, ShopPTD[playerid][z], 0);
			PlayerTextDrawSetOutline(playerid, ShopPTD[playerid][z], 0);
			if(ShData:Items[playerid][z] != -1) {
				new t = ShData:Items[playerid][z];
				PlayerTextDrawBackgroundColor(playerid, ShopPTD[playerid][z], 0x333333FF);
				PlayerTextDrawSetPreviewRot(playerid, ShopPTD[playerid][z], ItemInfo[t][ITEM_POS][0], ItemInfo[t][ITEM_POS][1], ItemInfo[t][ITEM_POS][2], ItemInfo[t][ITEM_POS][3]);
				PlayerTextDrawSetPreviewModel(playerid, ShopPTD[playerid][z], ItemInfo[t][ITEM_OBJECT]);

				format(gString, 20, "~g~$%d", ItemInfo[t][ITEM_PRICE]);
				ShopPricePTD[playerid][z] = CreatePlayerTextDraw(playerid, 190.099914 + (x * 33.000000), 169.949951 + (y * 31.9375), gString);
				PlayerTextDrawLetterSize(playerid, ShopPricePTD[playerid][z], 0.155500, 1.013749);
				PlayerTextDrawAlignment(playerid, ShopPricePTD[playerid][z], 3);
				PlayerTextDrawColor(playerid, ShopPricePTD[playerid][z], -1);
				PlayerTextDrawSetShadow(playerid, ShopPricePTD[playerid][z], 0);
				PlayerTextDrawSetOutline(playerid, ShopPricePTD[playerid][z], 0);
				PlayerTextDrawBackgroundColor(playerid, ShopPricePTD[playerid][z], 255);
				PlayerTextDrawFont(playerid, ShopPricePTD[playerid][z], 2);
				PlayerTextDrawSetProportional(playerid, ShopPricePTD[playerid][z], 1);
				PlayerTextDrawSetShadow(playerid, ShopPricePTD[playerid][z], 0);
				PlayerTextDrawShow(playerid, ShopPricePTD[playerid][z]);
				PlayerTextDrawSetSelectable(playerid, ShopPTD[playerid][z], true);	
			}
			else {
				PlayerTextDrawBackgroundColor(playerid, ShopPTD[playerid][z], 0x1F1F1FFF);
				PlayerTextDrawSetPreviewRot(playerid, ShopPTD[playerid][z], 0.000000, 0.000000, 0.800000, 0.699998);
				PlayerTextDrawSetPreviewModel(playerid, ShopPTD[playerid][z], 18685);
				PlayerTextDrawSetSelectable(playerid, ShopPTD[playerid][z], false);	
			}
			PlayerTextDrawFont(playerid, ShopPTD[playerid][z], 5);
			PlayerTextDrawSetProportional(playerid, ShopPTD[playerid][z], 0);
			PlayerTextDrawSetShadow(playerid, ShopPTD[playerid][z], 0);
			PlayerTextDrawSetPreviewVehCol(playerid, ShopPTD[playerid][z], 1, 1);
			PlayerTextDrawShow(playerid, ShopPTD[playerid][z]);		
			printf("%d %d", z, ShopPTD[playerid][z]);
			InvData:click_value[playerid][PlayerText:ShopPTD[playerid][z]] = z;
		} x=-1;
	} z=-1;
	while(++z<MAX_INVENTAR_ITEMS) {
		new rx = InvData:Type[playerid][z]; 
		InventarPTD[playerid][z] = CreatePlayerTextDraw(playerid, 332.700286 + ((z % INV_WITDH) * 33.000000), 147.599975 + ((z / INV_HEIGHT) * 31.9375), "");
		PlayerTextDrawLetterSize(playerid, InventarPTD[playerid][z], 0.000000, 0.000000);
		PlayerTextDrawTextSize(playerid, InventarPTD[playerid][z], 32.000000, 31.000000);
		PlayerTextDrawAlignment(playerid, InventarPTD[playerid][z], 1);
		PlayerTextDrawColor(playerid, InventarPTD[playerid][z], -1);
		PlayerTextDrawSetShadow(playerid, InventarPTD[playerid][z], 0);
		PlayerTextDrawSetOutline(playerid, InventarPTD[playerid][z], 0);
		PlayerTextDrawFont(playerid, InventarPTD[playerid][z], 5);
		PlayerTextDrawSetProportional(playerid, InventarPTD[playerid][z], 0);
		PlayerTextDrawSetShadow(playerid, InventarPTD[playerid][z], 0);
		PlayerTextDrawSetPreviewModel(playerid, InventarPTD[playerid][z], SlotInfo[rx][SLOT_OBJECT]);
		PlayerTextDrawSetPreviewRot(playerid, InventarPTD[playerid][z], SlotInfo[rx][SLOT_POS][0], SlotInfo[rx][SLOT_POS][1], SlotInfo[rx][SLOT_POS][2], SlotInfo[rx][SLOT_POS][3]);
		PlayerTextDrawBackgroundColor(playerid, InventarPTD[playerid][z], 0x1F1F1FFF);
		PlayerTextDrawSetPreviewVehCol(playerid, InventarPTD[playerid][z], 1, 1);
		PlayerTextDrawShow(playerid, InventarPTD[playerid][z]);		

		if(InvData:Value[playerid][z] < 2) continue;

		InventarValPTD[playerid][z] = CreatePlayerTextDraw(playerid, 363.599700 + ((z % INV_WITDH) * 33.000000), 169.300018 + ((z / INV_HEIGHT) * 31.9375), InvData:Info[playerid][z]);
		PlayerTextDrawLetterSize(playerid, InventarValPTD[playerid][z], 0.155500, 1.013749);
		PlayerTextDrawAlignment(playerid, InventarValPTD[playerid][z], 3);
		PlayerTextDrawColor(playerid, InventarValPTD[playerid][z], -1);
		PlayerTextDrawSetShadow(playerid, InventarValPTD[playerid][z], 0);
		PlayerTextDrawSetOutline(playerid, InventarValPTD[playerid][z], 0);
		PlayerTextDrawBackgroundColor(playerid, InventarValPTD[playerid][z], 255);
		PlayerTextDrawFont(playerid, InventarValPTD[playerid][z], 2);
		PlayerTextDrawSetProportional(playerid, InventarValPTD[playerid][z], 1);
		PlayerTextDrawSetShadow(playerid, InventarValPTD[playerid][z], 0);
		PlayerTextDrawShow(playerid, InventarValPTD[playerid][z]);
	}
	ShopPTD[playerid][30] = CreatePlayerTextDraw(playerid, 241.099975, 349.762451, "1");
	PlayerTextDrawLetterSize(playerid, ShopPTD[playerid][30], 0.256498, 1.569375);
	PlayerTextDrawAlignment(playerid, ShopPTD[playerid][30], 2);
	PlayerTextDrawColor(playerid, ShopPTD[playerid][30], -2139062017);
	PlayerTextDrawSetShadow(playerid, ShopPTD[playerid][30], 0);
	PlayerTextDrawSetOutline(playerid, ShopPTD[playerid][30], 0);
	PlayerTextDrawBackgroundColor(playerid, ShopPTD[playerid][30], 255);
	PlayerTextDrawFont(playerid, ShopPTD[playerid][30], 2);
	PlayerTextDrawSetProportional(playerid, ShopPTD[playerid][30], 1);
	PlayerTextDrawSetShadow(playerid, ShopPTD[playerid][30], 0);
	PlayerTextDrawShow(playerid, ShopPTD[playerid][30]);

	InventarPTD[playerid][36] = CreatePlayerTextDraw(playerid, 424.000000, 342.250000, "LD_BEAT:chit");
	PlayerTextDrawLetterSize(playerid, InventarPTD[playerid][36], 0.000000, 0.000000);
	PlayerTextDrawTextSize(playerid, InventarPTD[playerid][36], 10.000000, 9.000000);
	PlayerTextDrawAlignment(playerid, InventarPTD[playerid][36], 1);
	PlayerTextDrawColor(playerid, InventarPTD[playerid][36], 0xFF00FFFF);
	PlayerTextDrawSetShadow(playerid, InventarPTD[playerid][36], 0);
	PlayerTextDrawSetOutline(playerid, InventarPTD[playerid][36], 0);
	PlayerTextDrawBackgroundColor(playerid, InventarPTD[playerid][36], 255);
	PlayerTextDrawFont(playerid, InventarPTD[playerid][36], 4);
	PlayerTextDrawSetProportional(playerid, InventarPTD[playerid][36], 0);
	PlayerTextDrawSetShadow(playerid, InventarPTD[playerid][36], 0);
	PlayerTextDrawShow(playerid, InventarPTD[playerid][36]);			
	InvData:click_value[playerid][PlayerText:InventarPTD[playerid][36]] = 400;

	InventarPTD[playerid][37] = CreatePlayerTextDraw(playerid, 433.000000, 342.250000, "LD_BEAT:chit");
	PlayerTextDrawLetterSize(playerid, InventarPTD[playerid][37], 0.000000, 0.000000);
	PlayerTextDrawTextSize(playerid, InventarPTD[playerid][37], 10.000000, 9.000000);
	PlayerTextDrawAlignment(playerid, InventarPTD[playerid][37], 1);
	PlayerTextDrawColor(playerid, InventarPTD[playerid][37], 858993663);
	PlayerTextDrawSetShadow(playerid, InventarPTD[playerid][37], 0);
	PlayerTextDrawSetOutline(playerid, InventarPTD[playerid][37], 0);
	PlayerTextDrawBackgroundColor(playerid, InventarPTD[playerid][37], 255);
	PlayerTextDrawFont(playerid, InventarPTD[playerid][37], 4);
	PlayerTextDrawSetProportional(playerid, InventarPTD[playerid][37], 0);
	PlayerTextDrawSetShadow(playerid, InventarPTD[playerid][37], 0);
	PlayerTextDrawSetSelectable(playerid, InventarPTD[playerid][37], true);
	PlayerTextDrawShow(playerid, InventarPTD[playerid][37]);			
	InvData:click_value[playerid][PlayerText:InventarPTD[playerid][37]] = 401;
	invPage[playerid] = false;
	return true;
}

Shop:InvPage(playerid, bool:enable, z=-1, r=-1, rx=-1) {
	if(invPage[playerid]==enable) return true;
	invPage[playerid] = enable;
	PlayerTextDrawColor(playerid, InventarPTD[playerid][36], enable?858993663:0xFF00FFFF);
	PlayerTextDrawColor(playerid, InventarPTD[playerid][37], enable?0xFF00FFFF:858993663);
	PlayerTextDrawSetSelectable(playerid, InventarPTD[playerid][36], enable?true:false);
	PlayerTextDrawSetSelectable(playerid, InventarPTD[playerid][37], enable?false:true);
	PlayerTextDrawShow(playerid, InventarPTD[playerid][36]);
	PlayerTextDrawShow(playerid, InventarPTD[playerid][37]);
	if(invInfo[playerid][0] != -1) {
		for(new i=0;i<4;i++) PlayerTextDrawDestroy(playerid, invInfoPTD[playerid][i]), invInfoPTD[playerid][i] = PlayerText:INVALID_TEXT_DRAW;
		PlayerTextDrawSetSelectable(playerid, InventarPTD[playerid][invInfo[playerid][0]], true);
		PlayerTextDrawShow(playerid, InventarPTD[playerid][invInfo[playerid][0]]);
	}
	while(++z<MAX_INVENTAR_ITEMS) {
		r = (_:enable * MAX_INVENTAR_ITEMS) + z, rx=InvData:Type[playerid][r];
		PlayerTextDrawSetPreviewModel(playerid, InventarPTD[playerid][z], SlotInfo[rx][SLOT_OBJECT]);
		PlayerTextDrawSetPreviewRot(playerid, InventarPTD[playerid][z], SlotInfo[rx][SLOT_POS][0], SlotInfo[rx][SLOT_POS][1], SlotInfo[rx][SLOT_POS][2], SlotInfo[rx][SLOT_POS][3]);
		PlayerTextDrawBackgroundColor(playerid, InventarPTD[playerid][z], 0x1F1F1FFF);
		PlayerTextDrawShow(playerid, InventarPTD[playerid][z]);
		if(InventarValPTD[playerid][z] != PlayerText:INVALID_TEXT_DRAW) PlayerTextDrawDestroy(playerid, InventarValPTD[playerid][z]), InventarValPTD[playerid][z] = PlayerText:INVALID_TEXT_DRAW;
		if(InvData:Value[playerid][r]<2) continue;

		InventarValPTD[playerid][z] = CreatePlayerTextDraw(playerid, 363.599700 + ((z%INV_WITDH) * 33.000000), 169.300018 + ((z/INV_HEIGHT) * 31.9375), InvData:Info[playerid][r]);
		PlayerTextDrawLetterSize(playerid, InventarValPTD[playerid][z], 0.155500, 1.013749);
		PlayerTextDrawAlignment(playerid, InventarValPTD[playerid][z], 3);
		PlayerTextDrawColor(playerid, InventarValPTD[playerid][z], -1);
		PlayerTextDrawSetShadow(playerid, InventarValPTD[playerid][z], 0);
		PlayerTextDrawSetOutline(playerid, InventarValPTD[playerid][z], 0);
		PlayerTextDrawBackgroundColor(playerid, InventarValPTD[playerid][z], 255);
		PlayerTextDrawFont(playerid, InventarValPTD[playerid][z], 2);
		PlayerTextDrawSetProportional(playerid, InventarValPTD[playerid][z], 1);
		PlayerTextDrawSetShadow(playerid, InventarValPTD[playerid][z], 0);
		PlayerTextDrawShow(playerid, InventarValPTD[playerid][z]);	
	}
	return true;
}

Shop:Hide(playerid, i=-1) {
	if(!inShop[playerid]) return false;
	while(++i<5) TextDrawHideForPlayer(playerid, InventarTD[i]); i=-1;
	while(++i<7) TextDrawHideForPlayer(playerid, ShopTD[i]); i=-1;

	while(++i<MAX_SHOP_ITEMS) {
		PlayerTextDrawDestroy(playerid, ShopPTD[playerid][i]);
		if(ShopPricePTD[playerid][i] == PlayerText:INVALID_TEXT_DRAW) continue;
		PlayerTextDrawDestroy(playerid, ShopPricePTD[playerid][i]);
		ShopPricePTD[playerid][i] = PlayerText:INVALID_TEXT_DRAW;
	} i=-1;
	while(++i<MAX_INVENTAR_ITEMS) {
		PlayerTextDrawDestroy(playerid, InventarPTD[playerid][i]);
		if(InventarValPTD[playerid][i] == PlayerText:INVALID_TEXT_DRAW) continue;
		PlayerTextDrawDestroy(playerid, InventarValPTD[playerid][i]);
		InventarValPTD[playerid][i] = PlayerText:INVALID_TEXT_DRAW;
	}
	PlayerTextDrawDestroy(playerid, ShopPTD[playerid][30]);
	PlayerTextDrawDestroy(playerid, InventarPTD[playerid][36]);
	PlayerTextDrawDestroy(playerid, InventarPTD[playerid][37]);
	CancelSelectTextDraw(playerid);
	inShop[playerid] = false;
	return true;
}